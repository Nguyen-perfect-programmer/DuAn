<?php
require '../config/database.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION["reset_email"])) {
        header("Location: ../public/reset.php");
        exit();
    }

    $email = $_SESSION["reset_email"];
    $new_password = password_hash($_POST["new_password"], PASSWORD_BCRYPT);

    // Cập nhật mật khẩu mới
    $stmt = $conn->prepare("UPDATE users SET password_hash = :new_password WHERE email = :email");
    $stmt->bindParam(":new_password", $new_password);
    $stmt->bindParam(":email", $email);

    if ($stmt->execute()) {
        session_destroy(); // Xóa session reset email
        header("Location: ../public/auth.php?success=Đặt lại mật khẩu thành công! Hãy đăng nhập.");
        exit();
    } else {
        header("Location: ../public/new_password.php?error=Cập nhật thất bại!");
        exit();
    }
}
?>
