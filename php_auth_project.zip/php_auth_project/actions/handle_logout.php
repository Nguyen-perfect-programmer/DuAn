<?php
session_start();
session_destroy();
header("Location: ../public/auth.php?message=Bạn đã đăng xuất thành công!");
exit();
?>
