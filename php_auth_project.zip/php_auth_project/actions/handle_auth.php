<?php
require '../config/database.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST["action"];
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    if ($action == "register") {
        $username = trim($_POST["username"]);
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $role = "user"; // Luôn đăng ký với vai trò user

        // Ràng buộc: Họ và tên không được chứa ký tự đặc biệt, phải có ít nhất 3 ký tự
        if (!preg_match("/^[a-zA-ZÀ-Ỹà-ỹ\s]+$/u", $username)) {
            header("Location: ../public/auth.php?error=Họ và tên không được chứa ký tự đặc biệt!");
            exit();
        }
        if (mb_strlen($username, 'UTF-8') < 3) {
            header("Location: ../public/auth.php?error=Họ và tên phải có ít nhất 3 ký tự!");
            exit();
        }

        // Ràng buộc: Mật khẩu chỉ chứa chữ và số, phải có ít nhất 6 ký tự
        if (!preg_match("/^[a-zA-Z0-9]+$/", $password)) {
            header("Location: ../public/auth.php?error=Mật khẩu chỉ được chứa chữ và số!");
            exit();
        }
        if (strlen($password) < 6) {
            header("Location: ../public/auth.php?error=Mật khẩu phải có ít nhất 6 ký tự!");
            exit();
        }

        // Kiểm tra xem email đã tồn tại chưa
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = :email");
        $stmt->bindParam(":email", $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            header("Location: ../public/auth.php?error=Email đã tồn tại!");
            exit();
        }

        // Thêm tài khoản mới với vai trò user
        $stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, role) VALUES (:username, :email, :password, :role)");
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":password", $hashed_password);
        $stmt->bindParam(":role", $role);

        if ($stmt->execute()) {
            header("Location: ../public/auth.php?success=Đăng ký thành công! Hãy đăng nhập.");
            exit();
        } else {
            header("Location: ../public/auth.php?error=Đăng ký thất bại!");
            exit();
        }
    } elseif ($action == "login") {
        $stmt = $conn->prepare("SELECT id, username, password_hash, role FROM users WHERE email = :email");
        $stmt->bindParam(":email", $email);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user["password_hash"])) {
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["role"] = $user["role"];

            // Chuyển hướng theo role
            if ($user["role"] === "admin") {
                header("Location: ../public/admin_dashboard.php");
            } else {
                header("Location: ../public/dashboard.php");
            }
            exit();
        } else {
            header("Location: ../public/auth.php?error=Email hoặc mật khẩu không đúng!");
            exit();
        }
    }
}
?>
