<?php
require '../config/database.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);

    // Kiểm tra email có tồn tại không
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = :email");
    $stmt->bindParam(":email", $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        // Email tồn tại → Chuyển hướng đến trang đặt lại mật khẩu
        $_SESSION["reset_email"] = $email;
        header("Location: ../public/new_password.php");
        exit();
    } else {
        // Email không tồn tại
        header("Location: ../public/reset.php?error=Email không tồn tại!");
        exit();
    }
}
?>
