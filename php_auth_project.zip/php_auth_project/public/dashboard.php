<?php
session_start();

// Kiểm tra xem người dùng đã đăng nhập hay chưa
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "user") {
    header("Location: auth.php");
    exit();
}

// Lấy thông tin người dùng từ session
$username = isset($_SESSION["username"]) ? $_SESSION["username"] : "Người dùng";
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang người dùng</title>
    <link rel="stylesheet" href="css/style.css"> 
</head>
<body>
    <div class="success-container"> 
        <h2>Chào mừng, <?php echo htmlspecialchars($username); ?>!</h2>
        <p>Bạn đang đăng nhập với quyền <span class="user-role">User</span>.</p>
        
        <!-- Nút Đăng xuất -->
        <a href="../actions/logout.php" class="btn-logout">Đăng xuất</a>
    </div>
</body>
</html>
