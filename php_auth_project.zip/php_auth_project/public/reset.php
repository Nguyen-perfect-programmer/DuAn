<?php
$error = isset($_GET["error"]) ? $_GET["error"] : "";
$success = isset($_GET["success"]) ? $_GET["success"] : "";
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quên mật khẩu</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="reset-container">
        <h2>🔑 Quên mật khẩu</h2>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <p>Vui lòng nhập email để nhận liên kết đặt lại mật khẩu.</p>

        <form action="../actions/handle_reset.php" method="POST">
            <input type="email" name="email" placeholder="Nhập email của bạn" required>
            <button type="submit" class="btn-reset">📩 Gửi yêu cầu</button>
        </form>

        <a href="auth.php" class="back-to-login">⬅️ Quay lại đăng nhập</a>
    </div>
</body>
</html>
