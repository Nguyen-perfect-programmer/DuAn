<?php
session_start();

// Kiểm tra xem admin đã đăng nhập hay chưa
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: auth.php");
    exit();
}

// Lấy thông tin admin từ session
$admin_name = isset($_SESSION["username"]) ? $_SESSION["username"] : "Quản trị viên";
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang quản trị</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="admin-container">
        <h2>Chào mừng, <?php echo htmlspecialchars($admin_name); ?>!</h2>
        <p>Bạn đang đăng nhập với quyền <span class="admin-role">Admin</span>.</p>
        
        <div class="admin-menu">
            <a href="../actions/logout.php" class="btn-logout">Đăng xuất</a>
        </div>
    </div>
</body>
</html>
