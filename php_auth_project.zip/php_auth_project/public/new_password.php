<?php
session_start();
if (!isset($_SESSION["reset_email"])) {
    header("Location: reset.php");
    exit();
}

$error = isset($_GET["error"]) ? htmlspecialchars($_GET["error"]) : "";
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đặt lại mật khẩu</title>
    <link rel="stylesheet" href="css/style.css"> 
</head>
<body>
    <div class="reset-container">
        <h2>Đặt lại mật khẩu</h2>

        <?php if ($error): ?>
            <p class="error-msg"><?php echo $error; ?></p>
        <?php endif; ?>

        <form action="../actions/handle_new_password.php" method="POST">
            <label>Mật khẩu mới:</label>
            <input type="password" name="new_password" required><br><br>
            <button type="submit">Cập nhật mật khẩu</button>
        </form>

        <p><a href="auth.php" class="back-link">Quay lại đăng nhập</a></p>
    </div>
</body>
</html>
