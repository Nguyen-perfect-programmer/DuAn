<?php
session_start();
if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit();
}

$error = isset($_GET["error"]) ? $_GET["error"] : "";
$success = isset($_GET["success"]) ? $_GET["success"] : "";
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập / Đăng ký</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="form-wrapper">
        <!-- Form Đăng nhập -->
        <div class="form-container active" id="loginForm">
            <h2>Đăng nhập</h2>
            
            <?php if ($error) echo "<p class='error-msg'>$error</p>"; ?>
            <?php if ($success) echo "<p class='success-msg'>$success</p>"; ?>

            <form action="../actions/handle_auth.php" method="POST">
                <input type="hidden" name="action" value="login">
                <label>Email:</label>
                <input type="email" name="email" required>
                <label>Mật khẩu:</label>
                <input type="password" name="password" required>
                <button type="submit" class="btn btn-login">Đăng nhập</button>
            </form>

            <a href="reset.php" class="forgot-password">Quên mật khẩu?</a>
            <p>Chưa có tài khoản? <span class="toggle-btn" onclick="toggleForms()">Đăng ký ngay</span></p>
        </div>

        <!-- Form Đăng ký -->
        <div class="form-container" id="registerForm">
            <h2>Đăng ký</h2>

            <form action="../actions/handle_auth.php" method="POST">
                <input type="hidden" name="action" value="register">
                <label>Họ và tên:</label>
                <input type="text" name="username" required>

                <label>Email:</label>
                <input type="email" name="email" required>

                <label>Mật khẩu:</label>
                <input type="password" name="password" required>

                <button type="submit" class="btn btn-register">Đăng ký</button>
            </form>

            <p>Đã có tài khoản? <span class="toggle-btn" onclick="toggleForms()">Đăng nhập</span></p>
        </div>
    </div>

    <script>
        function toggleForms() {
            document.getElementById('loginForm').classList.toggle('active');
            document.getElementById('registerForm').classList.toggle('active');
        }
    </script>
</body>
</html>
