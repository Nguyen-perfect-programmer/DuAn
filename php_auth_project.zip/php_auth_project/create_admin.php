<?php
require 'config/database.php'; // Kết nối database

$email = 'pcnadmin@gmail.com';
$password = password_hash('12345', PASSWORD_BCRYPT); // Mã hóa mật khẩu
$role = 'admin';

$stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, role) VALUES ('Admin PCN', :email, :password, :role)");
$stmt->bindParam(':email', $email);
$stmt->bindParam(':password', $password);
$stmt->bindParam(':role', $role);

if ($stmt->execute()) {
    echo "✅ Tài khoản admin đã được tạo thành công!";
} else {
    echo "❌ Lỗi khi tạo tài khoản admin!";
}
?>
